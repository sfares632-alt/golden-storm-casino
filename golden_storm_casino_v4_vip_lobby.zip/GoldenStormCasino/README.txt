GOLDEN STORM CASINO — VERSION 4
================================

This is an offline-friendly, free-to-play casino-style slot game prototype.

WHAT'S NEW IN VERSION 4
- Animated main casino lobby
- Editable player name and selectable avatars
- 10 VIP ranks with XP progression
- VIP rank-up celebration and local coin rewards
- VIP club progress screen
- Daily and four-hour coin bonuses
- Four slot machines: Golden 777, Pharaoh's Treasure, Dragon's Fortune, Diamond Rush
- Local save data using browser storage
- No server, no real-money purchases, no deposits or withdrawals

HOW TO PLAY
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome recommended).
3. For Android, copy the extracted folder to your phone and open index.html with Chrome.
4. Tap the screen once if sound is enabled but not yet audible.

IMPORTANT
This is a playable HTML prototype, not yet a signed Android APK.
The game stores progress on the device/browser. Clearing browser data may erase progress.
Daily reward timers use the device clock and are not server-verified.
Virtual coins have no cash value and cannot be bought, sold, or redeemed.

NEXT ANDROID STEP
To publish as an installable Android app, the project still needs packaging (for example with Capacitor or a native Android wrapper), an app icon, application ID, device testing, and APK/AAB signing.
